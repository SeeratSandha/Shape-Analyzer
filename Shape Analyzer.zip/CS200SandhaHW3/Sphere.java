                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 3 (HW3)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 11/07/2023                             ***
                                        ***  Extra Credit : Accomplished                           ***
                                        **************************************************************/
public class Sphere implements Shape
{
    private double length;   // declaring the private instance variables. 
    private double width;
    private double height;
    private double weight;
    private double diameter;
    public Sphere(double diameter, double weight)  
                                 // constructor to inisitiate the object's instance variables 
    {
        this.diameter = diameter;
        this.weight = weight;
        System.out.println("A Sphere of diameter "+ diameter+", and weight "+ weight+" lb. was created.");
    }
    // Setter methods to setting the values of Length, Width, Height,and Weight
    public void setLength(double length)
    {
        this.length = length;
    }
    public void setWidth(double width)
    {
        this.width= width;
        
    }
    public void setHeight(double height)
    {
        this.height = height;
    }
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    
    // Getter methods to get the Length,Width, Height and Weight
    public double getLength()
    {
        return  length;
    }
    public double getWidth()
    {
         return width;
        
    }
    public double getHeight()
    {
        return  height;
    }
    public double getWeight()
    {
        return weight;
    }
    
    // calculateVolume for calculating the VOLUME of the 'Sphere'
    @Override
    public double calculateVolume(double length, double width, double height)
    {
        double firstCheck = Math.max(length, width);
        diameter = Math.max(firstCheck, height);
        double radius = diameter/2;
        double cubeRadius = Math.pow(radius,3);
        double numSolve = (4.0/3.0);
        double volume = numSolve*Math.PI*cubeRadius;
        return volume; 
    }
    // calculateDensity for calculating the DENSITY of 'Sphere'
    @Override
    public double calculateDensity(double length, double width, double height, double weight)
    {
        double density = weight/ calculateVolume(length, width,height);
        return density;
    }
    // calculateBestFit for calculating the MINIMUM-VOLUME of 'Sphere Container'
     @Override
    public double calculateBestFit()
    {
        
        double fit = diameter*diameter*diameter;
        return fit;
        
    }
    // calculateWaste for calculating the WASTE-SPACE in 'Sphere Container'
    @Override
    public double calculateWaste()
    {
        double volume = calculateVolume(length,width, height);
        double wastePercent =(calculateBestFit()-volume)/calculateBestFit();
        return wastePercent;
    }
    
}