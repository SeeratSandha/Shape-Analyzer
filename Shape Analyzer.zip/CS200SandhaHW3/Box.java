
                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 3 (HW3)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 11/07/2023                             ***
                                        ***  Extra Credit : Accomplished                           ***
                                        **************************************************************/

public class Box implements Shape //implementation
{
    private double length;   // declaring the private instance variables. 
    private double width;
    private double height;
    private double weight;
    public Box(double length, double width, double height, double weight)  
                                 // constructor to inisitiate the object's instance variables 
    {
        this.length = length;
        this.width= width;  
        this.height= height;
        this.weight = weight;
        
        System.out.println("A Box of length "+ length + ", width "+ width +", height "+height+", and weight "+weight +" lb. was created.");
    }
    // Setter methods for setting the values of the Length, Width, Height and Weight
    public void setLength(double length)
    {
        this.length = length;
    }
    public void setWidth(double width)
    {
        this.width= width;
    }
    public void setHeight(double height)
    {
        this.height = height;
    }
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    
    // getter methods for the Length , Width, Heigth and Weight values
    public double getLength()
    {
        return  length;
    }
    public double getWidth()
    {
         return width;
        
    }
    public double getHeight()
    {
        return  height;
    }
    public double getWeight()
    {
        return weight;
    }
    
    // calculateVolume method for calculating the VOLUME of the  object 'Box' 
    @Override
    public double calculateVolume(double length, double width, double height)
    {
        
        double volume = length* width* height;
        return volume;
    }
    
    // calculateDensity for calculating the DENSITY of the object 'Box' 
    @Override
    public double calculateDensity(double length, double width, double height, double weight)
    {
        double density = weight/ calculateVolume(length, width,height);
        return density;
    }
    
    // calculateBestFit for calculating the MINIMUM-VOLUME of  'Box Container'  
    @Override
    public double calculateBestFit()
    {
        
        double fit = getLength()*getHeight()*getWidth();
        return fit;
        
    }
    
    // calculateWaste for calculating the WASTE-SPACE in 'Box Container'
    @Override
    public double calculateWaste()
    {
        double volume = calculateVolume(length,width, height);
        double wastePercent =(calculateBestFit()-volume)/calculateBestFit();
        return wastePercent;
    }
    }
