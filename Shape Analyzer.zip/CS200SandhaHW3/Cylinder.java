                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 3 (HW3)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 11/07/2023                             ***
                                        ***  Extra Credit : Accomplished                           ***
                                        **************************************************************/

public class Cylinder implements Shape
{
    private double length;   // declaring the private instance variables. 
    private double width;
    private double height;
    private double weight;
    private double diameter;
    public Cylinder(double height, double diameter, double weight)  
                                 // constructor to inisitiate the object's instance variables 
    {
        this.height = height;
        this.diameter = diameter;
        this.weight = weight;
        System.out.println("A Cylinder of height "+ height+", diameter "+diameter +", and weight "+ weight+" lb. was created.");
    }
    // Setter methods to set the value of the Length, Width, Height, and Weight
    public void setLength(double length)
    {
        this.length = length;
    }
    public void setWidth(double width)
    {
        this.width= width;
        
    }
    public void setHeight(double height)
    {
        this.height = height;
    }
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    
    // Getter methods to get the value of the Length, Width, Height and Weight
    public double getLength()
    {
        return  length;
    }
    public double getWidth()
    {
         return width;
        
    }
    public double getHeight()
    {
        return  height;
    }
    public double getWeight()
    {
        return weight;
    }
    
    double heigthMaxValue =0;
    
    // calculateVolume for calculating the VOLUME of the 'Cylinder'
    @Override
    public double calculateVolume(double length, double width, double height)
    {
        double firstCheck = Math.max(length, width);
        heigthMaxValue = Math.max(firstCheck, height);
        double diameter  = 0;
        if(length== heigthMaxValue)
        {
            diameter = Math.max(width, height);
        }
        else if (width == heigthMaxValue)
        {
             diameter = Math.max(length, height);
             
        }
        else if (height == heigthMaxValue )
        {
             diameter = Math.max(length, width);
        }
        double radius = diameter/2;
        double SqrRadius = Math.pow(radius,2);
        double volume = Math.PI*SqrRadius*(heigthMaxValue);
        return volume; 
    }
    // calculateDensity for calculating the DENSITY of the 'Cylinder'
    @Override
    public double calculateDensity(double length, double width, double height, double weight)
    {
        double density = weight/ calculateVolume(length, width,height);
        return density;
    }
    // calculateBestFit for calculating the MINIMUM-VOLUME  of the 'Cylinder Container' 
    @Override
    public double calculateBestFit()
    {
        double fit = diameter*diameter*heigthMaxValue;
        return fit;
    }
    // calculateWaste for calculating WASTE-SPACE for the 'Cylinder Container'
    @Override
    public double calculateWaste()
    {
        
        double volume = calculateVolume(length,width, height);   
        double wastePercent =(calculateBestFit()-volume)/calculateBestFit();
        return wastePercent;
    }
    
}