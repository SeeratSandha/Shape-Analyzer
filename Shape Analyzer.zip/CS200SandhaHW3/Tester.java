                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 3 (HW3)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 11/07/2023                             ***
                                        ***  Extra Credit : Accomplished                           ***
                                        **************************************************************/



import java.util.Scanner;
import java.util.*;

public class Tester 
{
    public static void main(String args[])
    {
        // prompting the user for the values of Length, Width, Height and Weight 
        Scanner scnr = new Scanner(System.in);
        System.out.println("Enter the value of the Length");
        double length =0.0;
        boolean checkLength = true;
        while(checkLength)
        {
         try
        {
            String input = scnr.next();
            length = Double.parseDouble(input);
            if(length <=0.00)// throwing an exception if user enter the Negative or Zero as the value of the Length 
            {
             throw new InputMismatchException("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
            }
            else
            {
                checkLength = false;
            }
            
        }
        
        catch(InputMismatchException ie)
        // throwing an exception if user enter the inappropriate value of the Length
        {
            System.out.println(ie.getMessage());
            System.out.println("Enter the value of the Length");
           
            
        }
        catch (NumberFormatException nfe)
        {
                System.out.println("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
                System.out.println("Enter the value of the Length");
                //Prompting again for values
               
        }
    }
        System.out.println("Enter the value of the Width");
        double width = 0.00;
        boolean checkWidth = true;
         while(checkWidth)
        {
         try
        {
             String input = scnr.next();
             width = Double.parseDouble(input);
             // throwing an exception if user enter the Negative or Zero as the value of the Width
            if(width <=0.00)
            {
             
             throw new InputMismatchException("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
            }
            else
            {
                checkWidth = false;
            }
            
        }
        
        catch(InputMismatchException ie)
        // throwing an exception if user enter the inappropriate value of the Width
        {
            System.out.println(ie.getMessage());
            System.out.println("Enter the value of the Width");
           
            
        }catch (NumberFormatException nfe)
        {
                System.out.println("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
                System.out.println("Enter the value of the width");
                //Prompting again for values
               
        }
    }    
        
        System.out.println("Enter the value of the Height");
        double height = 0.00;
        boolean checkHeight = true;
         while(checkHeight)
        {
         try
        {
                   
             String input = scnr.next();
             height = Double.parseDouble(input);
            if(height <=0.00)
            // throwing an exception if user enter the Negative or Zero as the value of the Height
            {
             throw new InputMismatchException("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
            }
            else
            {
                checkHeight = false;
            }
          }
        
        catch(InputMismatchException ie)
        {
            // throwing an exception if user enter the inappropriate value of the Height
            System.out.println(ie.getMessage());
            System.out.println("Enter the value of the Height");
        }
        catch (NumberFormatException nfe)
        {
                System.out.println("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
                System.out.println("Enter the value of the height");
                //Prompting again for values
               
        }
    }
        
        System.out.println("Enter the value of the Weight");
        double weight = 0.00;
        boolean checkWeight = true;
         while(checkWeight)
        {
         try
        {
            String input = scnr.next();
            weight = Double.parseDouble(input);
            if(weight <=0.00)
             // throwing an exception if user enter the Negative or Zero as the value of the Weight

            {
             throw new InputMismatchException("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
            }
            else
            {
                checkWeight= false;
            }
        }
        
        catch(InputMismatchException ie)
        {
             // throwing an exception if user enter the inappropriate value of the Weight 

            System.out.println(ie.getMessage());
            System.out.println("Enter the value of the Weight");
        }
        catch (NumberFormatException nfe)
        {
                System.out.println("Invalid entry. Only positive values > 0 are allowed. Please re-enter.");
                System.out.println("Enter the value of the weight");
               //Prompting again for values 
        }
    }
    
    // assigning the maximum of: height, length, and width as the height.
    // assigning the second greatest value of the three as a diameter. 
    
        double firstCheck = Math.max(length, width);
        double maxValue  = Math.max(firstCheck, height);
        double secondMaxValue  = 0;
        if(length== maxValue)
        {
            secondMaxValue = Math.max(width, height);
        }
        else if ( width == maxValue)
        {
             secondMaxValue = Math.max(length, height);
             
        }
        else if (height == maxValue )
        {
             secondMaxValue = Math.max(length, width);
        }
        
        // Creating the objects box, cone, cylinder and sphere for classes Box, Cone,Cylinder and Sphere, respectively. 
        Box box = new Box(length, width, height, weight);
        Cone cone = new Cone(maxValue ,secondMaxValue, weight);
        Cylinder cylinder = new Cylinder(maxValue, secondMaxValue, weight);
        Sphere sphere = new Sphere(maxValue,weight);
        
        // Calling the setter methods of each objects using the method accessor modifiers. 
        
        box.setLength(length);
        box.setWidth(width);
        box.setHeight(height);
        box.setWeight(weight);
        
        cone.setLength(length);
        cone.setWidth(width);
        cone.setHeight(height);
        cone.setWeight(weight);
        
        cylinder.setLength(length);
        cylinder.setWidth(width);
        cylinder.setHeight(height);
        cylinder.setWeight(weight);
        
        sphere.setLength(length);
        sphere.setWidth(width);
        sphere.setHeight(height);
        sphere.setWeight(weight);
        
    
        // Calling and display the properties of each shape 
        double boxVolume = box.calculateVolume(length, width, height);
        double boxDensity = box.calculateDensity(length, width, height, weight);
        System.out.printf("\nBox volume: %.2f cu ft,\t Box density: %.2f lbs./cu ft%n", boxVolume, boxDensity);

        // using the pritnf statement , Accomplishing the Extra credit task. 
        
        double coneVolume = cone.calculateVolume(length, width, height);
        double coneDensity = cone.calculateDensity(length, width, height, weight);
         System.out.printf("Cone volume: %.2f cu ft,\t Cone density: %.2f lbs./cu ft%n",coneVolume, coneDensity);
        
         double cylinderVolume = cylinder.calculateVolume(length, width, height);
         double cylinderDensity = cylinder.calculateDensity(length, width, height, weight);
         System.out.printf("Cylinder volume: %.2f cu ft, \t Cylinder density: %.2f lbs./cu ft%n",cylinderVolume, cylinderDensity);

         
        double sphereVolume = sphere.calculateVolume(length, width, height);
        double sphereDensity = sphere.calculateDensity(length, width, height, weight);
        System.out.printf("sphere  volume: %.2f cu ft, \t sphere  density: %.2f lbs./cu ft%n",sphereVolume, sphereDensity);
        
        
        

        // Calculate minimum container dimensions and wasted space
        // multiplying the calcuateWaste method with 100 to find the percentage. 
        System.out.println("\nAn object container would need to be:");
        double boxContainerVolume = box.calculateBestFit();
        double boxWaste = box.calculateWaste();
        System.out.printf("%.2f cu ft for a Box (%.2f%% waste)%n",boxContainerVolume, boxWaste*100);
        
        double coneContainerVolume = cone.calculateBestFit();
        double coneWaste = cone.calculateWaste();
        System.out.printf("%.2f cu ft for a Cone (%.2f%% waste)%n",coneContainerVolume, coneWaste*100);
        
        double cylinderContainerVolume = cylinder.calculateBestFit();
        double cylinderWaste = cylinder.calculateWaste();
        System.out.printf("%.2f cu ft for a Cylinder (%.2f%% waste)%n",cylinderContainerVolume, cylinderWaste*100);
        
        
        double sphereContainerVolume = sphere.calculateBestFit();
        double sphereWaste = sphere.calculateWaste();
        System.out.printf("%.2f cu ft for a Sphere (%.2f%% waste)%n",sphereContainerVolume, sphereWaste*100);
        
    
    
    
    
}
}
