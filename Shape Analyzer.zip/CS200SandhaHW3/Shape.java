                                       /**************************************************************
                                        ***  Project Name : CS 200 Programming Assignment 3 (HW3)  ***
                                        ***  Author       : Seerat Sandha                          ***
                                        ***  Date         : 11/07/2023                             ***
                                        ***  Extra Credit : Accomplished                           ***
                                        **************************************************************/




public interface Shape 
{
    
    
    // Setter methods for the dimensions
    public void setLength(double length);
    public void setWidth(double width);
    public void setHeight(double height);
    public void setWeight(double weight);
    
    // Getter methods for the dimensions 
    public double getLength();
    public double getWidth();
    public double getHeight();
    public double getWeight();
    
    // Method to calculate the Volume for the container of the shape 
    public double calculateVolume(double length, double width, double height);
    // Method to calculate the Density for the container of the shape 
    public double calculateDensity(double length, double width, double height, double weight);
    // Method to calculate the minimum volume dimensions for a container to hold the shape
    public double calculateBestFit();
    // Method to calculate the amount of wasted space for a container for the shape
    public double calculateWaste();
}

